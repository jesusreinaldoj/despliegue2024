let boton=document.getElementById("boton");
let divJesus=document.getElementById("jesus");

boton.onclick=clickboton;

function clickboton(){

    divJesus.style.backgroundColor="red";

}